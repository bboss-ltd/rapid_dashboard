{{--
    @extends('layouts.app')

    @section('content')
        sprintSnapshot.index template
    @endsection
--}}
