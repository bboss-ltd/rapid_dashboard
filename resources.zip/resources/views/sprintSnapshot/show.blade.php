{{--
    @extends('layouts.app')

    @section('content')
        sprintSnapshot.show template
    @endsection
--}}
