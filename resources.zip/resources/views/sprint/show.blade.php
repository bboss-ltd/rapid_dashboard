{{--
    @extends('layouts.app')

    @section('content')
        sprint.show template
    @endsection
--}}
