{{--
    @extends('layouts.app')

    @section('content')
        sprint.index template
    @endsection
--}}
