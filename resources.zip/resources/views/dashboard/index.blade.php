{{--
    @extends('layouts.app')

    @section('content')
        dashboard.index template
    @endsection
--}}
