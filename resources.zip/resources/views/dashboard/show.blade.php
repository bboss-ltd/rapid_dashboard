{{--
    @extends('layouts.app')

    @section('content')
        dashboard.show template
    @endsection
--}}
